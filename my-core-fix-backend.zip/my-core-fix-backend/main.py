
from flask import Flask, request, jsonify

app = Flask(__name__)

PRODUCTS = [
    {"tag": "sleep_aid", "name": "Sleep Reset Mist", "image_url": "https://cdn.com/sleepmist.png", "product_url": "https://yourdropshipsource.com/sleepmist", "blurb": "This mist helps you fall asleep faster and improves sleep depth naturally."},
    {"tag": "anti_snore", "name": "Snore Block Nose Vents", "image_url": "https://cdn.com/snoreblock.png", "product_url": "https://yourdropshipsource.com/snoreblock", "blurb": "Reduces snoring by opening nasal passages and improving airflow while sleeping."},
    {"tag": "confidence_boost", "name": "Self-Belief Journal", "image_url": "https://cdn.com/confidencejournal.png", "product_url": "https://yourdropshipsource.com/journal", "blurb": "Guided prompts to rebuild self-worth and reduce anxiety."},
    {"tag": "skin_health", "name": "Hydrating Face Mask", "image_url": "https://cdn.com/face_mask.png", "product_url": "https://yourdropshipsource.com/face_mask", "blurb": "Soothes dry or acne-prone skin with botanical hydration."},
    {"tag": "posture_support", "name": "Posture Corrector Band", "image_url": "https://cdn.com/posture_band.png", "product_url": "https://yourdropshipsource.com/posture_band", "blurb": "Gently supports your back and encourages upright posture throughout the day."},
    {"tag": "energy_boost", "name": "Natural Energy Drops", "image_url": "https://cdn.com/energy_drops.png", "product_url": "https://yourdropshipsource.com/energy_drops", "blurb": "Reduces reliance on caffeine while supporting mental clarity and stamina."},
    {"tag": "stress_relief", "name": "Calm Tea Blend", "image_url": "https://cdn.com/calm_tea.png", "product_url": "https://yourdropshipsource.com/calm_tea", "blurb": "Naturally eases stress with herbs like chamomile and ashwagandha."},
    {"tag": "productivity_tools", "name": "Productivity Planner", "image_url": "https://cdn.com/productivity_planner.png", "product_url": "https://yourdropshipsource.com/productivity_planner", "blurb": "Helps organize daily tasks and build lasting routines."},
    {"tag": "social_comfort", "name": "Social Ease Gummies", "image_url": "https://cdn.com/social_gummies.png", "product_url": "https://yourdropshipsource.com/social_gummies", "blurb": "Promotes a calm mind in social settings with a blend of herbal ingredients."}
]

def assign_tags(fields):
        tags = []

        # Build a map of label → selected answer text
        answers = {}
        for field in fields:
            label = field.get("label")
            value_ids = field.get("value", [])
            options = field.get("options", [])

            # Convert selected ID to actual text
            selected_texts = [opt["text"] for opt in options if opt["id"] in value_ids]
            if selected_texts:
                answers[label] = selected_texts[0]

        # Now match tags based on interpreted answers
        if answers.get("How well do you sleep most nights?") == "I struggle to fall or stay asleep":
            tags.append("sleep_aid")
        if answers.get("How often do you feel confident in yourself or your appearance?") == "Rarely":
            tags.append("confidence_boost")
        if answers.get("How is your skin on most days?") == "Dry, irritated, or acne-prone":
            tags.append("skin_health")
        if answers.get("Do you struggle with posture or body discomfort during the day?") == "Yes, often":
            tags.append("posture_support")
        if answers.get("Do you get tired easily or rely on caffeine?") == "Yes, constantly":
            tags.append("energy_boost")
        if answers.get("How often do you feel stressed or overwhelmed?") == "Almost every day":
            tags.append("stress_relief")
        if answers.get("Do you find social situations draining or awkward?") == "Yes":
            tags.append("social_comfort")
        if answers.get("Are you generally productive or disciplined with your time?") == "Not at all":
            tags.append("productivity_tools")

        return tags


def match_products(tags):
    return [product for product in PRODUCTS if product["tag"] in tags]

@app.route("/analyze", methods=["POST"])
def analyze():
        data = request.get_json()
        fields = data.get("data", {}).get("fields", [])
        tags = assign_tags(fields)
        matched_products = match_products(tags)

        print({"tags": tags, "products": matched_products})

        return jsonify({"tags": tags, "products": matched_products})




if __name__ == "__main__":
    app.run(debug=True)
